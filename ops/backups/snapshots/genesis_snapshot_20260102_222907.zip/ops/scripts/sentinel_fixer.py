import subprocess
import os
import sys

# --- CONFIGURATION ---
ENV_FILE = ".env"
CONTAINER_NAME = "db_core"
ROOT_USER = "root_admin"

def load_env():
    env_vars = {}
    if not os.path.exists(ENV_FILE):
        print(f"❌ Error: {ENV_FILE} not found.")
        sys.exit(1)
    with open(ENV_FILE, 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                parts = line.strip().split('=', 1)
                if len(parts) == 2:
                    env_vars[parts[0]] = parts[1]
    return env_vars

def run_sql(db, sql, password):
    cmd = [
        "docker", "exec", "-e", f"PGPASSWORD={password}", 
        CONTAINER_NAME, "psql", "-U", ROOT_USER, "-d", db, 
        "-c", sql
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"⚠️ Warning in DB {db}: {result.stderr.strip()}")
    return result

def main():
    print("🚀 SENTINEL FIXER: Iniciando Protocolo de Mantenimiento...")
    env = load_env()
    root_pass = env.get("POSTGRES_ROOT_PASSWORD")
    
    if not root_pass:
        print("❌ Error: POSTGRES_ROOT_PASSWORD not in .env")
        sys.exit(1)

    # 1. FIX EXTENSIONS (Chatwoot)
    print("\n📦 [1/3] Habilitando Extensiones (Chatwoot)...")
    extensions = [
        "pg_trgm", "pgcrypto", "pg_stat_statements", "btree_gin"
    ]
    for ext in extensions:
        run_sql("chatwoot", f"CREATE EXTENSION IF NOT EXISTS {ext};", root_pass)
    print("✅ Extensiones verificadas.")

    # 2. FIX PERMISSIONS (Public Schema)
    print("\n🔐 [2/3] Corrigiendo Permisos de Esquema (Postgres 15)...")
    apps = {
        "chatwoot": "chatwoot_user",
        "evolution": "evolution_user",
        "n8n": "n8n_user"
    }
    for db, user in apps.items():
        run_sql(db, f"GRANT ALL ON SCHEMA public TO {user};", root_pass)
    print("✅ Permisos otorgados.")

    # 3. SYNC PASSWORDS
    print("\n🔄 [3/3] Sincronizando Contraseñas de Roles...")
    passwords = {
        "chatwoot_user": env.get("CHATWOOT_DB_PASSWORD"),
        "evolution_user": env.get("EVOLUTION_DB_PASSWORD"),
        "n8n_user": env.get("N8N_DB_PASSWORD")
    }
    for user, pwd in passwords.items():
        if pwd:
            run_sql("postgres", f"ALTER USER {user} WITH PASSWORD '{pwd}';", root_pass)
    print("✅ Contraseñas sincronizadas.")

    print("\n✨ PROTOCOLO COMPLETADO: Sistema Blindado y Operativo.")

if __name__ == "__main__":
    main()
