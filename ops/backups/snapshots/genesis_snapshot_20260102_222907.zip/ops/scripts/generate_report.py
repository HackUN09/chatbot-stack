import os

def get_env_vars():
    vars = {}
    with open('.env', 'r') as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, val = line.strip().split('=', 1)
                vars[key] = val
    return vars

env = get_env_vars()

content = f"""# 🚀 Isekai Stack v1.0 - Acceso Final

**Estado del Sistema**: `OPERATIONAL`
**Modo**: `HARDENED / PRODUCTION-LOCAL`

## 🔑 Bóveda de Credenciales (The Vault)

### Infraestructura (Core)
| Servicio | Usuario | Contraseña |
| :--- | :--- | :--- |
| **Postgres Root** | `root_admin` | `{env.get('POSTGRES_ROOT_PASSWORD')}` |
| **Redis** | - | `{env.get('REDIS_PASSWORD')}` |
| **MinIO** | `minioadmin` | `{env.get('MINIO_ROOT_PASSWORD')}` |

### Aplicaciones (App Layer)
| Aplicación | Usuario DB Segregado | Clave Maestra / API Key |
| :--- | :--- | :--- |
| **Chatwoot** | `chatwoot_user` | `{env.get('CHATWOOT_DB_PASSWORD')}` |
| *(Chatwoot)* | - | `SECRET_KEY_BASE`: `{env.get('SECRET_KEY_BASE')}` |
| **Evolution** | `evolution_user` | `{env.get('EVOLUTION_DB_PASSWORD')}` |
| *(Evolution)* | `AUTHENTICATION_API_KEY` | `{env.get('EVOLUTION_API_KEY')}` |
| **n8n** | `n8n_user` | `{env.get('N8N_DB_PASSWORD')}` |
| *(n8n)* | `N8N_ENCRYPTION_KEY` | `{env.get('N8N_ENCRYPTION_KEY')}` |

## 🌐 Accesos Globales (Cloudflare Tunnel)
Estas URLs son accesibles desde cualquier lugar del mundo.

*   **Chatwoot**: [https://chat.isekaichat.com](https://chat.isekaichat.com)
*   **Evolution API**: [https://api.isekaichat.com](https://api.isekaichat.com)
    *   *Docs*: [https://api.isekaichat.com/docs](https://api.isekaichat.com/docs) (Si activado)
*   **n8n Workflows**: [https://n8n.isekaichat.com](https://n8n.isekaichat.com)
*   **MinIO S3 API**: [https://s3.isekaichat.com](https://s3.isekaichat.com)

## 🔒 Accesos Locales (Administración)
Solo accesibles desde este servidor (`127.0.0.1`).

*   **PgAdmin 4** (Base de Datos): [http://localhost:80](http://localhost:80)
    *   *Email*: `admin@isekaichat.com`
    *   *Pass*: `{env.get('PGADMIN_DEFAULT_PASSWORD')}`
*   **MinIO Console** (Archivos): [http://localhost:9001](http://localhost:9001)
*   **Redis Insight** (Caché): [http://localhost:5540](http://localhost:5540)

## 🎮 Sistema Maestro (Command Center)
Para gestionar tu imperio, usa el script maestro desde Git Bash:

```bash
./sistema_maestro.sh
```

**Menú Principal:**
1.  **Start All**: Inicia todo en orden correcto.
2.  **Stop All**: Apagado seguro.
3.  **HUD**: Monitor de recursos estilo Cyberpunk.
4.  **Auto Doctor**: Diagnóstico de fallos.

---
> [!IMPORTANT]
> Guarda este archivo en un lugar seguro. Contiene las llaves de acceso total a tu infraestructura.
"""

path = r"C:\Users\wamr1\.gemini\antigravity\brain\70d52d6a-c44b-4654-aa88-5c57af7d05b4\walkthrough.md"
with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Walkthrough generated.")
