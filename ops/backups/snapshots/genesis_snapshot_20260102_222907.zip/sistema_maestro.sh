#!/bin/bash

# ==============================================================================
#  ISEKAI STACK - SISTEMA MAESTRO v4.0 (GOD MODE - THE MATRIX EDITION)
#  "Libera tu Mente, Domina tu Infraestructura"
# ==============================================================================

# --- PALETA DE COLORES (THE MATRIX & CYBERPUNK) ---
M_GREEN='\033[38;5;46m'   # Matrix Green
M_DARK='\033[38;5;22m'    # Dark Green
C_PINK='\033[38;5;198m'   # Neon Pink
C_CYAN='\033[38;5;51m'    # Neon Cyan
C_WHITE='\033[1;37m'      # Pure White
C_YELLOW='\033[38;5;226m' # Power Yellow
C_RED='\033[0;31m'        # Alert Red
NC='\033[0m'              # No Color
BOLD='\033[1m'

MAESTRO_ROOT=$(pwd)
ENV_FILE="${MAESTRO_ROOT}/.env"

function print_matrix_header() {
    clear
    echo -e "${M_GREEN}"
    echo "   ███╗   ███╗ █████╗ ████████╗██████╗ ██╗██╗  ██╗"
    echo "   ████╗ ████║██╔══██╗╚══██╔══╝██╔══██╗██║╚██╗██╔╝"
    echo "   ██╔████╔██║███████║   ██║   ██████╔╝██║ ╚███╔╝ "
    echo "   ██║╚██╔╝██║██╔══██║   ██║   ██╔══██╗██║ ██╔██╗ "
    echo "   ██║ ╚═╝ ██║██║  ██║   ██║   ██║  ██║██║██╔╝ ██╗"
    echo "   ╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝"
    echo -e "   ${C_CYAN}─── SENTINEL OS // GOD MODE v4.0 // CONNECTED ───${NC}"
    echo -e "   ${M_DARK}═════════════════════════════════════════════════${NC}"
}

function show_links() {
    if [ -f "$ENV_FILE" ]; then
        DOMAIN=$(grep DOMAIN .env | cut -d '=' -f2)
    else
        DOMAIN="isekaichat.com"
    fi
    echo -e "   ${BOLD}${C_WHITE}🌐 GATEWAY CLOUDFLARE (ACCESO GLOBAL):${NC}"
    echo -e "    ├─ 💬 Chatwoot:  ${C_CYAN}https://chat.${DOMAIN}${NC}"
    echo -e "    ├─ 🧬 Evolution: ${C_CYAN}https://api.${DOMAIN}${NC}"
    echo -e "    └─ ⚡ n8n Core:  ${C_CYAN}https://n8n.${DOMAIN}${NC}"
    echo ""
    echo -e "   ${BOLD}${C_WHITE}🔒 TERMINAL DE MANDO (ADMIN LOCAL):${NC}"
    echo -e "    ├─ 🐘 PgAdmin 4:      ${C_YELLOW}http://localhost:5050${NC}"
    echo -e "    ├─ 📦 MinIO Console:  ${C_YELLOW}http://localhost:9001${NC}"
    echo -e "    └─ 🧠 Redis Insight:  ${C_YELLOW}http://localhost:5540${NC}"
}

function status_hud() {
    while true; do
        print_matrix_header
        echo -e "   ${BOLD}${C_PINK}📡 MONITOR DE SISTEMA (LIVE)${NC}"
        echo -e "   ──────────────────────────────────────"
        docker ps --format "   {{.Names}} >> {{.Status}}" | \
        sed "s/Up/$(echo -e "${M_GREEN}ONLINE${NC}")/g" | \
        sed "s/Restarting/$(echo -e "${C_RED}FAILURE${NC}")/g" | \
        sed "s/Exited/$(echo -e "${C_WHITE}OFFLINE${NC}")/g"
        echo ""
        echo -e "   ${C_WHITE}[R] Recargar  [Q] Salir al Menú${NC}"
        read -n 1 -s key
        if [[ $key == "q" ]]; then break; fi
    done
}

function start_sequence() {
    print_matrix_header
    echo -e "   ${M_GREEN}⚡ INICIANDO PROTOCOLO GÉNESIS...${NC}"
    echo ""
    echo -n -e "   [1/3] Levantando Base de Datos e Infra... "
    docker compose -f modules/01-infra/docker-compose.yml --env-file .env up -d > /dev/null 2>&1
    echo -e "${M_GREEN}OK${NC}"
    
    echo -n -e "   [WAIT] Calibrando Sincronía SQL (10s)... "
    sleep 10
    echo -e "${C_CYAN}LISTO${NC}"
    
    echo -n -e "   [2/3] Desplegando Núcleos de Aplicación... "
    docker compose -f modules/02-apps/docker-compose.yml --env-file .env up -d > /dev/null 2>&1
    echo -e "${M_GREEN}OK${NC}"
    
    echo -n -e "   [3/3] Abriendo Túnel Cuántico Cloudflare... "
    docker compose -f modules/03-tunnel/docker-compose.yml --env-file .env up -d > /dev/null 2>&1
    echo -e "${M_GREEN}OK${NC}"
    
    echo ""
    echo -e "   ${C_PINK}🎉 SISTEMA TOTALMENTE OPERATIVO.${NC}"
    show_links
    read -p "Presiona Enter..."
}

function stop_sequence() {
    print_matrix_header
    echo -e "   ${C_RED}💀 INICIANDO PROTOCOLO DE SUSPENSIÓN TOTAL...${NC}"
    docker compose -f modules/03-tunnel/docker-compose.yml down
    docker compose -f modules/02-apps/docker-compose.yml down
    docker compose -f modules/01-infra/docker-compose.yml down
    echo -e "   ${M_GREEN}✨ Desconexión Segura Completada.${NC}"
    read -p "Presiona Enter..."
}

function backup_logic() {
    print_matrix_header
    echo -e "   ${C_CYAN}📸 PROTOCOLO GÉNESIS SNAPSHOT${NC}"
    echo -e "   1. Snapshot de Código y Configuración (.zip)"
    echo -e "   2. Dump de Bases de Datos (.sql)"
    echo -e "   0. Volver"
    read -p "   Selección >> " b_opt
    case $b_opt in
        1) python ops/scripts/genesis_snapshot.py ;;
        2) 
            echo "   Generando Dumps de Postgres..."
            timestamp=$(date +"%Y%m%d_%H%M%S")
            root_pass=$(grep POSTGRES_ROOT_PASSWORD .env | cut -d '=' -f2)
            for db in chatwoot evolution n8n; do
                docker exec -e PGPASSWORD=$root_pass db_core pg_dump -U root_admin -d $db > ops/backups/${db}_backup_${timestamp}.sql
                echo "   ✅ Backup de $db listo."
            done
            ;;
    esac
    read -p "Presiona Enter..."
}

function vault_reveal() {
    print_matrix_header
    echo -e "   ${C_PINK}🔐 ACCESO A LA BOVEDA SEGURA${NC}"
    echo -e "   ──────────────────────────────────────"
    echo -e "   User Admin: ${C_WHITE}$(grep PGADMIN_DEFAULT_EMAIL .env | cut -d '=' -f2)${NC}"
    echo -e "   Pass Admin: ${C_WHITE}$(grep PGADMIN_DEFAULT_PASSWORD .env | cut -d '=' -f2)${NC}"
    echo -e "   Evolution API Key: ${M_GREEN}$(grep EVOLUTION_API_KEY .env | cut -d '=' -f2)${NC}"
    echo ""
    echo -e "   ${M_DARK}Tus secretos están encriptados en el .env${NC}"
    read -p "Presiona Enter para cerrar."
}

# --- MENU PRINCIPAL ---
while true; do
    print_matrix_header
    echo -e "   ${C_PINK}[ MÓDULO: NÚCLEO DE ENERGÍA ]${NC}"
    echo -e "    ${M_GREEN}1. ⚡ Lanzar Sistema Completo${NC}"
    echo -e "    ${C_RED}2. 💀 Suspensión Total (Stop)${NC}"
    echo ""
    echo -e "   ${C_PINK}[ MÓDULO: DIAGNÓSTICO Y REPARACIÓN ]${NC}"
    echo -e "    ${C_CYAN}3. 📡 Monitor Dinámico (HUD)${NC}"
    echo -e "    ${C_CYAN}4. 🔍 Inmersión en Logs${NC}"
    echo -e "    ${C_CYAN}5. ⚕️  Sentinel Doctor & Fixer${NC}"
    echo ""
    echo -e "   ${C_PINK}[ MÓDULO: SEGURIDAD Y DATOS ]${NC}"
    echo -e "    ${C_YELLOW}6. 📸 Génesis Snapshot (Backups)${NC}"
    echo -e "    ${C_YELLOW}7. 🔐 Ver la Bóveda (Access List)${NC}"
    echo ""
    echo -e "   ${C_WHITE}0. 🚪 Salir de Sentinel OS${NC}"
    echo ""
    echo -n -e "   ${BOLD}${M_GREEN}SENTINEL@ROOT >> ${NC}"
    read opt

    case $opt in
        1) start_sequence ;;
        2) stop_sequence ;;
        3) status_hud ;;
        4) 
            print_matrix_header
            echo -e "   ${C_WHITE}Selecciona flujo de datos:${NC}"
            echo "   1) Chatwoot  2) Evolution  3) n8n  4) Postgres  0) Atrás"
            read -p "   >> " l_opt
            case $l_opt in
                1) docker logs -f chatwoot-web ;;
                2) docker logs -f app_evolution ;;
                3) docker logs -f app_n8n_editor ;;
                4) docker logs -f db_core ;;
            esac
            ;;
        5) 
            print_matrix_header
            echo -e "   ${M_GREEN}⚕️  CHEQUEANDO CONSTANTES VITALES...${NC}"
            db_status=$(docker exec db_core pg_isready -U root_admin > /dev/null 2>&1 && echo -e "${M_GREEN}ONLINE${NC}" || echo -e "${C_RED}ERROR${NC}")
            redis_status=$(docker exec cache_core redis-cli -a $(grep REDIS_PASSWORD .env | cut -d '=' -f2) ping > /dev/null 2>&1 && echo -e "${M_GREEN}PONG${NC}" || echo -e "${C_RED}DOWN${NC}")
            echo -e "   Núcleo DB: $db_status"
            echo -e "   Caché Central: $redis_status"
            echo ""
            echo -e "   ${C_WHITE}[F] Iniciar Auto-Reparación (Sentinel Fixer)${NC}"
            echo -e "   [Enter] Volver"
            read -n 1 -s fix
            if [[ $fix == "f" ]]; then
                echo -e "   ${C_CYAN}🛠️  Ejecutando Sentinel Fixer Protocol...${NC}"
                python ops/scripts/sentinel_fixer.py
                read -p "   Reparación finalizada. Enter..."
            fi
            ;;
        6) backup_logic ;;
        7) vault_reveal ;;
        0) clear; exit 0 ;;
    esac
done
